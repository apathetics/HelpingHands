//
//  MaxDistanceTableViewCell.swift
//  Helping Hands
//
//  Created by Manasa Tipparam on 4/4/18.
//  Copyright © 2018 Tracy Nguyen. All rights reserved.
//

import Foundation

class MaxDistanceTableViewCell: UITableViewCell {
    @IBOutlet weak var distanceSlider: UISlider!
    @IBOutlet weak var distLBL: UILabel!
    @IBOutlet weak var maxDistanceLBL: UILabel!
}
